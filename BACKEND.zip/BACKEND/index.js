import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";
import bodyParser from "body-parser";
import cookieParser from "cookie-parser";

import userRoutes from "./routes/UserRoutes.js";
import eventRoutes from "./routes/EventRoutes.js";
import errorLogger from "./middlewares/errorHandling.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || "https://meeting-event-scheduling-platform.vercel.app";
const MONGO_URI = process.env.MONGO_URI;

// Middleware
app.use(cors({
    origin: CLIENT_ORIGIN,
    credentials: true,
}));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(errorLogger);

// Routes
app.use("/user", userRoutes);
app.use("/event", eventRoutes);

// Start server
app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});

// Connect to MongoDB
if (!MONGO_URI) {
    console.error("MongoDB connection string is missing. Set MONGO_URI in .env file.");
    process.exit(1);
}

mongoose.connect(MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    tlsAllowInvalidCertificates: true
}).then(() => {
    console.log("Connected to MongoDB");
}).catch((error) => {
    console.error("MongoDB connection error:", error);
    process.exit(1);
});
