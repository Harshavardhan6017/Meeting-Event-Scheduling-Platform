import express from "express";
import dotenv from "dotenv";
import Meeting from "../models/EventModel.js";
import errorLogger from "../middlewares/errorHandling.js";
import { authMiddleware } from "../middlewares/AuthMiddleWare.js";

dotenv.config();
const eventRoutes = express.Router();

eventRoutes.get("/:id", errorLogger, async (req, res) => {
    try {
        const { id } = req.params;
        const events = await Meeting.find({ createdBy: id });
        
        if (!events.length) {
            return res.status(404).json({ message: "No events found" });
        }
        res.status(200).json({ data: events, message: "Data fetch successful" });
    } catch (error) {
        errorLogger(error, req, res);
    }
});


eventRoutes.get("/eventId/:id", errorLogger, async (req, res) => {
    try {
        const event = await Meeting.findById(req.params.id);
        if (!event) {
            return res.status(404).json({ message: "Event not found" });
        }
        res.status(200).json({ data: event, message: "Data fetch successful" });
    } catch (error) {
        errorLogger(error, req, res);
    }
});


eventRoutes.get("/upcomingEvent/:id", errorLogger, async (req, res) => {
    try {
        const { id } = req.params;
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const upcomingMeetings = await Meeting.find({
            "invited_users.user_id": id,
            date: { $gte: today }
        }).sort({ date: 1, startTime: 1 });

        res.status(200).json(upcomingMeetings.length ? upcomingMeetings : { message: "No upcoming events found" });
    } catch (error) {
        errorLogger(error, req, res);
    }
});


eventRoutes.get("/pendingEvent/:id", errorLogger, async (req, res) => {
    try {
        const { id } = req.params;
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const pendingMeetings = await Meeting.find({
            "invited_users": { $elemMatch: { user_id: id, status: "pending" } },
            date: { $gte: today }
        }).sort({ date: 1, startTime: 1 });

        res.status(200).json(pendingMeetings.length ? pendingMeetings : { message: "No pending events found" });
    } catch (error) {
        errorLogger(error, req, res);
    }
});


eventRoutes.post("/addEvent", errorLogger, async (req, res) => {
    try {
        const newMeeting = new Meeting(req.body);
        const savedMeeting = await newMeeting.save();
        res.status(201).json({ message: "Event created successfully", result: savedMeeting });
    } catch (error) {
        errorLogger(error, req, res);
    }
});


eventRoutes.put("/updateEvent/:id/:userId", errorLogger, async (req, res) => {
    try {
        const { id, userId } = req.params;
        const event = await Meeting.findById(id);
        if (!event) return res.status(404).json({ message: "Meeting not found" });
        if (event.createdBy.toString() !== userId) return res.status(403).json({ message: "Unauthorized" });

        const updatedMeeting = await Meeting.findByIdAndUpdate(id, req.body, { new: true });
        res.status(200).json({ message: "Meeting updated", result: updatedMeeting });
    } catch (error) {
        errorLogger(error, req, res);
    }
});

// Update event status
eventRoutes.put("/updateEventStatus/:id/:userId/:status", errorLogger, async (req, res) => {
    try {
        const { id, userId, status } = req.params;
        const updatedMeeting = await Meeting.findOneAndUpdate(
            { _id: id, "invited_users.user_id": userId },
            { $set: { "invited_users.$.status": status } },
            { new: true }
        );
        if (!updatedMeeting) return res.status(404).json({ message: "Meeting not found" });

        res.status(200).json({ message: `Meeting ${status}`, result: updatedMeeting });
    } catch (error) {
        errorLogger(error, req, res);
    }
});

// Delete an event
eventRoutes.delete("/deleteEvent/:id/:userId", errorLogger, async (req, res) => {
    try {
        const { id, userId } = req.params;
        const event = await Meeting.findById(id);
        if (!event) return res.status(404).json({ message: "Meeting not found" });
        if (event.createdBy.toString() !== userId) return res.status(403).json({ message: "Unauthorized" });

        await Meeting.findByIdAndDelete(id);
        res.status(200).json({ message: "Meeting deleted" });
    } catch (error) {
        errorLogger(error, req, res);
    }
});

export default eventRoutes;
