import express from "express";
import errorLogger from "../middlewares/errorHandling.js";
import userModel from "../models/UserModel.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();
const routes = express.Router();

routes.get("/:id", errorLogger, async (req, res) => {
    try {
        const { id } = req.params;
        const foundUser = await userModel.findById(id);

        if (!foundUser) {
            return res.status(404).json({ message: "User not found" });
        }
        
        res.status(200).json({ result: foundUser });
    } catch (error) {
        errorLogger(error, req, res);
    }
});

routes.get("/email/:id", errorLogger, async (req, res) => {
    try {
        const { id } = req.params;
        const foundUser = await userModel.findOne({ email: id });

        if (!foundUser) {
            return res.status(404).json({ message: "User not found" });
        }

        res.status(200).json({ message: "User found", id: foundUser._id, username: foundUser.userName });
    } catch (error) {
        errorLogger(error, req, res);
    }
});

routes.post("/signup", errorLogger, async (req, res) => {
    try {
        const { firstName, lastName, email, password } = req.body;
        
        if (await userModel.findOne({ email })) {
            return res.status(409).json({ message: "Email already in use" });
        }
        
        const hashPassword = bcrypt.hashSync(password, parseInt(process.env.BCRYPT_SALT));
        const newUser = new userModel({ firstName, lastName, email, password: hashPassword });

        await newUser.save();
        res.status(201).json({ message: "User created successfully" });
    } catch (error) {
        errorLogger(error, req, res);
    }
});

routes.post("/signin", errorLogger, async (req, res) => {
    try {
        const { email, password } = req.body;
        const foundUser = await userModel.findOne({ email });

        if (!foundUser || !(await bcrypt.compare(password, foundUser.password))) {
            return res.status(400).json({ message: "Incorrect email or password" });
        }
        
        const token = jwt.sign({ userId: foundUser._id, email: foundUser.email }, process.env.JWT_SECRET, { expiresIn: "7d" });
        res.cookie("token", token, { httpOnly: true });

        res.status(200).json({ message: "Login successful", id: foundUser._id });
    } catch (error) {
        errorLogger(error, req, res);
    }
});

routes.put("/update/:id", errorLogger, async (req, res) => {
    try {
        const { id } = req.params;
        const { events } = req.body;
        
        const updatedUser = await userModel.findByIdAndUpdate(id, { $push: { events: { $each: events } } }, { new: true });
        
        if (!updatedUser) {
            return res.status(404).json({ message: "User not found" });
        }
        
        res.status(200).json({ message: "Update successful", result: updatedUser });
    } catch (error) {
        errorLogger(error, req, res);
    }
});

routes.put("/updateUser/:id", errorLogger, async (req, res) => {
    try {
        const { id } = req.params;
        let data = req.body;

        if (data.password) {
            data.password = bcrypt.hashSync(data.password, parseInt(process.env.BCRYPT_SALT));
        }

        const updatedUser = await userModel.findByIdAndUpdate(id, data, { new: true });
        if (!updatedUser) {
            return res.status(404).json({ message: "User not found" });
        }
        
        res.status(200).json({ message: "User updated successfully", result: updatedUser });
    } catch (error) {
        errorLogger(error, req, res);
    }
});

routes.put("/availability/:id", errorLogger, async (req, res) => {
    try {
        const { id } = req.params;
        const availabilityArray = req.body;
        
        const foundUser = await userModel.findById(id);
        if (!foundUser) {
            return res.status(404).json({ message: "No user found" });
        }
        
        availabilityArray.forEach(({ day, timeSlots }) => {
            const existingDay = foundUser.availability.find(avail => avail.day === day);
            if (existingDay) {
                existingDay.timeSlots = timeSlots;
            } else {
                foundUser.availability.push({ day, timeSlots });
            }
        });

        await foundUser.save();
        res.status(200).json({ message: "Availability updated", availability: foundUser.availability });
    } catch (error) {
        errorLogger(error, req, res);
    }
});

export default routes;
