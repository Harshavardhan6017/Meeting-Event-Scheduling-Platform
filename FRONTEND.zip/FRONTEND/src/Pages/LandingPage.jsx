import React from "react";
import { useNavigate } from "react-router";
import styles from "./LandingPage.module.css";

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div id={styles.pageContainer}>
      {/* Navigation Bar */}
      <nav id={styles.navBar}>
        <div id={styles.logSection}>
          <img src="./Vector.png" alt="Cube-logo" />
          <h1>CNNCT</h1>
        </div>
        <button onClick={() => navigate("/signup")} id={styles.landingPageButton}>
          Sign up free
        </button>
      </nav>

      {/* Main Content */}
      <main id={styles.MainContainer}>
        <section id={styles.headingLandingPage}>
          <h1>CNNCT – Easy</h1>
          <h1>Scheduling Ahead</h1>
          <button onClick={() => navigate("/signup")} id={styles.landingPageButton}>
            Sign up free
          </button>
          <img id={styles.screen1Img} src="./screen1.png" alt="Demo screen" />
          <h1>Simplified scheduling for you and your team</h1>
          <p>
            CNNCT eliminates the back-and-forth of scheduling meetings so you can focus on what matters. Set your availability, share your link, and let others book time with you instantly.
          </p>
        </section>

        {/* Features Section */}
        <section id={styles.subSection}>
          <div id={styles.subSectionDesc}>
            <h1>Stay Organized with Your Calendar & Meetings</h1>
            <p>Seamless Event Scheduling</p>
            <ul>
              <li>View all your upcoming meetings and appointments in one place.</li>
              <li>Syncs with Google Calendar, Outlook, and iCloud to avoid conflicts.</li>
              <li>Customize event types: one-on-ones, team meetings, and webinars.</li>
            </ul>
          </div>
          <div id={styles.subSectionImg}>
            <img src="./Fantastical1.png" alt="Calendar" />
            <img src="./screen3.png" alt="Scheduling example" />
          </div>
        </section>

        {/* Testimonials */}
        <section id={styles.subSection1}>
          <h1>Here's what our <span className={styles.blueHeading}>customers</span> say</h1>
          <button id={styles.subSection1Btn}>Read customer stories</button>
        </section>

        {/* Customer Reviews */}
        <section id={styles.chipSection}>
          {[...Array(4)].map((_, index) => (
            <div key={index} className={styles.chip}>
              <h4>Amazing tool! Saved me months</h4>
              <p>This is a placeholder for your testimonials. Make sure they are meaningful.</p>
              <div className={styles.lowerSection}>
                <div className={styles.blueDot}></div>
                <div className={styles.lowerSectionDetails}>
                  <p>John Master</p>
                  <p>Director, Spark.com</p>
                </div>
              </div>
            </div>
          ))}
        </section>

        {/* Integrations */}
        <section className={styles.integration}>
          <h1>All Link Apps and Integrations</h1>
        </section>
        
        {/* App Integrations */}
        <section id={styles.section3Container}>
          {[...Array(9)].map((_, index) => (
            <div key={index} className={styles.Container}>
              <img src={`./icon${index + 1}.png`} alt="Integration icon" />
              <div className={styles.ContainerDetails}>
                <p>Integration {index + 1}</p>
                <p>Integration description</p>
              </div>
            </div>
          ))}
        </section>

        {/* Footer */}
        <footer className={styles.landingPageFooter}>
          <div className={styles.footerSide1}>
            <div className={styles.footerBtn}>
              <button onClick={() => navigate("/signin")} className={styles.footerBtnLogIn}>Log in</button>
              <button onClick={() => navigate("/signup")} className={styles.footerBtnSignUp}>Sign up free</button>
            </div>
            <div className={styles.footerSide2}>
              {["About CNNCT", "Careers", "Terms and Conditions", "Blog", "Getting Started", "Privacy Policy", "Press", "Features and How-Tos", "FAQs", "Trust Center", "Contact", "Report a Violation"].map((text, index) => (
                <p key={index}>{text}</p>
              ))}
            </div>
          </div>
          <button onClick={() => navigate("/signup")} className={styles.footerBtnSignUpMobile}>Sign up free</button>
          <div className={styles.footerSide3}>
            <p>We acknowledge the Traditional Custodians of the land on which our office stands...</p>
            <div className={styles.footerIcon}>
              {["twitter", "insta", "youtube", "tiktok", "cnn"].map((icon, index) => (
                <img key={index} src={`./${icon}.png`} alt={icon} />
              ))}
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
