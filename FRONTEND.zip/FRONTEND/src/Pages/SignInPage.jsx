import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Link, useNavigate } from "react-router-dom";
import styles from "./SignInPage.module.css";

export default function SignInPage() {
  const [loading, setLoading] = useState(false);
  const apiUrl = import.meta.env.VITE_API_KEY;
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch(`${apiUrl}user/signin`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
        credentials: "include",
      });
      const data = await res.json();

      if (res.status !== 200) {
        toast.error(data.message);
      } else {
        const userRes = await fetch(`${apiUrl}user/${data.id}`);
        const userData = await userRes.json();
        localStorage.setItem("username", userData.result.userName);
        localStorage.setItem("userId", userData.result._id);
        navigate(userData.result.userName ? "/HomePage" : "/Preference");
        toast.success("Login successful!");
      }
    } catch (error) {
      console.error(error);
      toast.error("Something went wrong!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {loading && <div className={styles.loadingOverlay}>Loading...</div>}
      <form className={styles.formContainer} onSubmit={handleSubmit}>
        <section className={styles.formSection}>
          <div className={styles.logoContainer}>
            <img src="./Vector.png" alt="Logo" />
            <h1>CNNCT</h1>
          </div>
          <h1 className={styles.signInHeader}>Sign in</h1>
          <label>Email</label>
          <input type="email" id="email" value={formData.email} onChange={handleChange} required />
          <label>Password</label>
          <div className={styles.passwordField}>
            <input type={showPassword ? "text" : "password"} id="password" value={formData.password} onChange={handleChange} required />
            <button type="button" onClick={() => setShowPassword(!showPassword)}>
              {showPassword ? "Hide" : "Show"}
            </button>
          </div>
          <button type="submit" className={styles.submitBtn}>Log in</button>
          <p>
            Don't have an account? <Link to="/signup">Sign up</Link>
          </p>
        </section>
        <section className={styles.imageSection}>
          <img src="./banner.png" alt="Banner" />
        </section>
      </form>
      <ToastContainer position="top-center" autoClose={5000} />
    </>
  );
}
